﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;

namespace RijEncryption
{
    class Program
    {
        static void Main(string[] args)
        {
            RijndaelManaged symAlgo = new RijndaelManaged();
            Console.WriteLine("Generated key: {0}, \n Generated IV: {1}", Encoding.Default.GetString(symAlgo.Key), Encoding.Default.GetString(symAlgo.IV));
            Console.Read();
        }
    }
}
